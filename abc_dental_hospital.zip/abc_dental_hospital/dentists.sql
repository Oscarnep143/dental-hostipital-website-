-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 10, 2024 at 08:43 AM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abc_dental_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `dentists`
--

DROP TABLE IF EXISTS `dentists`;
CREATE TABLE IF NOT EXISTS `dentists` (
  `dentist_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `specialty` varchar(255) NOT NULL,
  `bio` text,
  PRIMARY KEY (`dentist_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `dentists`
--

INSERT INTO `dentists` (`dentist_id`, `name`, `specialty`, `bio`) VALUES
(1, 'Dr. Sarah Johnson', 'Orthodontist', 'Expert in orthodontic treatments and smile corrections.'),
(2, 'Dr. Michael Smith', 'Periodontist', 'Specialist in gum health and periodontal disease treatments.'),
(3, 'Dr. Emily Davis', 'Prosthodontist', 'Provides comprehensive prosthetic solutions for missing teeth.'),
(4, 'Dr. David Lee', 'Endodontist', 'Focused on root canal therapy and internal tooth health.'),
(5, 'Dr. Jessica Martinez', 'Pediatric Dentist', 'Dedicated to providing dental care to children.'),
(6, 'Dr. Sarah Johnson', 'Orthodontist', NULL),
(7, 'Dr. Michael Smith', 'Periodontist', NULL),
(8, 'Dr. Emily Davis', 'Prosthodontist', NULL),
(9, 'Dr. David Lee', 'Endodontist', NULL),
(10, 'Dr. Jessica Martinez', 'Pediatric Dentist', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
