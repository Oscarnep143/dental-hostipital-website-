<!DOCTYPE html>
<head style>
    <title style>ABC Dental Hospital</title>
    <link rel="stylesheet" href="site.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body style="background-color:#0AECFD;">
 <label class="logo" ><strong><h1 style="color: rgba(59, 177, 207, 0.915);">ABC DENTAL HOSPITAL </h1></strong></label>
 
 <div class="main">
   <nav>
    <div class="nav-links">
      <ul>
    <li><a href="index.php" class="home1">Home</a></li>
    <li><a href="about.php" class="photos1">About us </a></li>
    <li><a href="doctor.php" class="aboutwebsite1">Our service</a></li>
     <li><a href="contact.php" class="contacts1">Contact</a></li>
      </ul>
   </nav> 
 </div>
 <main>
  <h1>Meet Our Dentists</h1>
    
  <section>
      <h3>Dr. Sarah Johnson - Orthodontist</h3>
    
  </section>

  <section>
      <h3>Dr. Michael Smith - Periodontist</h3>
  </section>

  <section>
      <h3>Dr. Emily Davis - Prosthodontist</h3>
  </section>
     

  <section>
      <h3>Dr. David Lee - Endodontist</h3>
     
  </section>

  <section>
      <h3>Dr. Jessica Martinez - Pediatric Dentist</h3>
      </div>
    </section>

    <div class="box">
        <h2>Meet Our Dentist Team</h2>
        <!-- Insert the team photo below -->
        <img id = "welcome_small" src="images\istockphoto-687663822-612x612.jpg">
        <p>At ABC Hospital, we take pride in offering high-quality dental care, tailored to meet the individual needs of every patient. Our highly experienced team of dentists is committed to providing a comfortable and stress-free experience, ensuring that each visit is as pleasant as possible. Whether you need a routine check-up, cosmetic dentistry, or advanced dental treatments, our team is here to support your dental health journey..</p>
    </div> 

  </div>
</main>
</body>

<footer>

<div class="social-links">
  <ul>
  <li><a href="https://www.facebook.com/profile.php?id=100054698164244&mibextid=LQQJ4d" class="social-items"><i class="fa-brands fa-facebook fa-beat"></i></a></li>
  <li><a href="https://instagram.com/oscarneupane?igshid=MmIzYWVlNDQ5Yg==" class="social-items"><i class="fa-brands fa-instagram fa-beat"></i></a></li>
  <li><a href="https://www.youtube.com/@oscarvlogs4086" class="social-items"><i class="fa-brands fa-youtube fa-beat"></i></a></li>
  <li><a href="https://www.linkedin.com/in/oscar-neupane-659a41266" class="social-items"><i class="fa-brands fa-linkedin fa-beat"></i></a></li>
</ul>
   
 </div>

<div class="copyright">
<p>copyright &copy;2024 ABCDENTALHOSPITAL. designed by oscarneupane</p>
</div>
</footer>
</html>
