<!DOCTYPE html>
<head style>
    <title style>ABC Dental Hospital</title>
    <link rel="stylesheet" href="site.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body style="background-color:#0AECFD;">
 <label class="logo" ><strong><h1 style="color: rgba(59, 177, 207, 0.915);">ABC DENTAL HOSPITAL </h1></strong></label>
 
 <div class="main">
    <nav>
        <div class="nav-links">
          <ul>
    <li><a href="index.php" class="home1">Home</a></li>
    <li><a href="about.php" class="photos1">About us </a></li>
    <li><a href="doctor.php" class="aboutwebsite1">Our service</a></li>
     <li><a href="contact.php" class="contacts1">Contact</a></li>
          </ul>
       </nav>
 </div>
 <main>
    <form action="submit_appointment.php" method="POST">
        <label for="dentist">Choose a Dentist Specialist:</label>
        <select id="dentist" name="dentist" required>
            <option value="">Select a specialist</option>
            <option value="Dr. Sarah Johnson - Orthodontist">Dr. Sarah Johnson - Orthodontist</option>
            <option value="Dr. Michael Smith - Periodontist">Dr. Michael Smith - Periodontist</option>
            <option value="Dr. Emily Davis - Prosthodontist">Dr. Emily Davis - Prosthodontist</option>
            <option value="Dr. David Lee - Endodontist">Dr. David Lee - Endodontist</option>
            <option value="Dr. Jessica Martinez - Pediatric Dentist">Dr. Jessica Martinez - Pediatric Dentist</option>
        </select>

        <br><br>

        <label for="appointment_date">Preferred Appointment Date:</label>
        <input type="date" id="appointment_date" name="appointment_date" required>

        <br><br>

        <label for="patient_name">Your Name:</label>
        <input type="text" id="patient_name" name="patient_name" placeholder="Enter your name" required>

        <br><br>

        <label for="contact_info">Contact Information:</label>
        <input type="text" id="contact_info" name="contact_info" placeholder="Phone or Email" required>

        <br><br>

        <button type="submit">Book Appointment</button>
    </form>

</body>
</html>