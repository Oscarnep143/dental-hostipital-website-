-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 10, 2024 at 08:24 AM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abc_dental_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
CREATE TABLE IF NOT EXISTS `appointments` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int UNSIGNED DEFAULT NULL,
  `appointment_date` date NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_info`
--

DROP TABLE IF EXISTS `contact_info`;
CREATE TABLE IF NOT EXISTS `contact_info` (
  `contact_id` int NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `social_facebook` varchar(255) DEFAULT NULL,
  `social_instagram` varchar(255) DEFAULT NULL,
  `social_youtube` varchar(255) DEFAULT NULL,
  `social_linkedin` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contact_info`
--

INSERT INTO `contact_info` (`contact_id`, `address`, `phone`, `email`, `social_facebook`, `social_instagram`, `social_youtube`, `social_linkedin`) VALUES
(1, '123 Dental St, Cityname, Country', '555-1234', 'info@abcdentalhospital.com', 'https://www.facebook.com/profile.php?id=100054698164244', 'https://instagram.com/oscarneupane', 'https://www.youtube.com/@oscarvlogs4086', 'https://www.linkedin.com/in/oscar-neupane-659a41266');

-- --------------------------------------------------------

--
-- Table structure for table `dentists`
--

DROP TABLE IF EXISTS `dentists`;
CREATE TABLE IF NOT EXISTS `dentists` (
  `dentist_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `specialty` varchar(255) NOT NULL,
  `bio` text,
  PRIMARY KEY (`dentist_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `dentists`
--

INSERT INTO `dentists` (`dentist_id`, `name`, `specialty`, `bio`) VALUES
(1, 'Dr. Sarah Johnson', 'Orthodontist', 'Expert in orthodontic treatments and smile corrections.'),
(2, 'Dr. Michael Smith', 'Periodontist', 'Specialist in gum health and periodontal disease treatments.'),
(3, 'Dr. Emily Davis', 'Prosthodontist', 'Provides comprehensive prosthetic solutions for missing teeth.'),
(4, 'Dr. David Lee', 'Endodontist', 'Focused on root canal therapy and internal tooth health.'),
(5, 'Dr. Jessica Martinez', 'Pediatric Dentist', 'Dedicated to providing dental care to children.');

-- --------------------------------------------------------

--
-- Table structure for table `footer_info`
--

DROP TABLE IF EXISTS `footer_info`;
CREATE TABLE IF NOT EXISTS `footer_info` (
  `footer_id` int NOT NULL AUTO_INCREMENT,
  `footer_text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`footer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `footer_info`
--

INSERT INTO `footer_info` (`footer_id`, `footer_text`) VALUES
(1, 'Copyright © 2024 ABCDENTALHOSPITAL. Designed by oscarneupane');

-- --------------------------------------------------------

--
-- Table structure for table `navigation_links`
--

DROP TABLE IF EXISTS `navigation_links`;
CREATE TABLE IF NOT EXISTS `navigation_links` (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `link_name` varchar(100) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `navigation_links`
--

INSERT INTO `navigation_links` (`link_id`, `link_name`, `url`) VALUES
(1, 'Home', 'index.php'),
(2, 'About Us', 'about.php'),
(3, 'Our Service', 'doctor.php'),
(4, 'Contact', 'contact.php');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `service_id` int NOT NULL AUTO_INCREMENT,
  `service_name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`service_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_name`, `description`) VALUES
(1, 'General Dentistry', 'Routine check-ups, cleanings, and fillings.'),
(2, 'Cosmetic Dentistry', 'Teeth whitening, veneers, and smile makeovers.'),
(3, 'Orthodontics', 'Braces and clear aligners for teeth alignment.'),
(4, 'Dental Surgery', 'Root canals, implants, and other surgical procedures.'),
(5, 'Pediatric Dentistry', 'Dental care for children.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
