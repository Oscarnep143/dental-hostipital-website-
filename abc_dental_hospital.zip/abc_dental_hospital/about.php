<!DOCTYPE html>
<head style>
    <title style>SERVICE</title>
    <link rel="stylesheet" href="site.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body style="background-color:#0AECFD;">
 <label class="logo" ><strong><h1 style="color: rgba(59, 177, 207, 0.915);">ABC DENTAL HOSPITAL </h1></strong></label>
 
 <div class="main">
   <nav>
    <div class="nav-links">
      <ul>
    <li><a href="index.php" class="home1">Home</a></li>
    <li><a href="about.php" class="photos1">About us </a></li>
    <li><a href="doctor.php" class="aboutwebsite1">Our service</a></li>
     <li><a href="contact.php" class="contacts1">Contact</a></li>
          </ul>
   </nav>
   <h1>About ABC Dental Hospital</h1>
   <p>
       ABC Dental Hospital is committed to providing exceptional dental care with a focus on patient comfort, quality service, 
       and modern dental solutions. Our experienced team of professionals is dedicated to promoting optimal oral health 
       through personalized treatment plans in a welcoming environment. Whether you're visiting for routine checkups or more 
       complex dental procedures, we prioritize your satisfaction and overall well-being.
   </p>

   <h2>Our Services</h2>
   <p>At ABC Dental Hospital, we offer a comprehensive range of dental services tailored to meet the unique needs of each patient:</p>

   <h3>1. General Dentistry</h3>
   <p>
       Our general dentistry services include routine checkups, cleanings, fillings, and preventive care aimed at maintaining 
       your dental health. We focus on early detection and education to ensure long-term oral wellness.
   </p>

   <h3>2. Cosmetic Dentistry</h3>
   <p>
       Achieve the smile of your dreams with our cosmetic services, including teeth whitening, veneers, and smile makeovers. 
       We work with you to enhance the aesthetics of your smile while ensuring its function and health.
   </p>

   <h3>3. Orthodontics</h3>
   <p>
       We provide orthodontic treatments like braces and clear aligners to correct misaligned teeth and bite issues. 
       Our goal is to give you a straight, healthy smile that improves both appearance and oral function.
   </p>

   <h3>4. Pediatric Dentistry</h3>
   <p>
       Our pediatric dentistry services cater to the unique needs of children, from infancy through adolescence. 
       We create a friendly and relaxing environment to ensure a positive dental experience for our youngest patients.
   </p>

   <h3>5. Periodontics</h3>
   <p>
       Specializing in gum health, our periodontists offer treatments for gum disease, including scaling and root planing, 
       gum surgery, and periodontal maintenance to prevent tooth loss and improve oral health.
   </p>

   <h3>6. Endodontics (Root Canal Treatment)</h3>
   <p>
       Our endodontic services focus on saving natural teeth by treating infections and inflammation in the dental pulp. 
       We use advanced techniques to perform comfortable and effective root canal treatments.
   </p>

   <h3>7. Prosthodontics (Dental Implants & Restorations)</h3>
   <p>
       From dental implants to crowns, bridges, and dentures, our prosthodontic services are designed to restore your teeth 
       and improve both function and appearance. We provide lasting solutions to enhance your smile.
   </p>

   <h3>8. Emergency Dental Care</h3>
   <p>
       We offer prompt emergency dental services for patients dealing with pain, trauma, or urgent dental issues. 
       Whether it’s a broken tooth or severe toothache, our team is ready to assist you with immediate care.
   </p>

</body>
</html>
       

</body>

<footer>

<div class="social-links">
  <ul>
  <li><a href="https://www.facebook.com/profile.php?id=100054698164244&mibextid=LQQJ4d" class="social-items"><i class="fa-brands fa-facebook fa-beat"></i></a></li>
  <li><a href="https://instagram.com/oscarneupane?igshid=MmIzYWVlNDQ5Yg==" class="social-items"><i class="fa-brands fa-instagram fa-beat"></i></a></li>
  <li><a href="https://www.youtube.com/@oscarvlogs4086" class="social-items"><i class="fa-brands fa-youtube fa-beat"></i></a></li>
  <li><a href="https://www.linkedin.com/in/oscar-neupane-659a41266" class="social-items"><i class="fa-brands fa-linkedin fa-beat"></i></a></li>
</ul>
   
 </div>

<div class="copyright">
<p>copyright &copy;2023 OAIAS. designed by oscarneupane</p>
</div>
</footer>
</html>
