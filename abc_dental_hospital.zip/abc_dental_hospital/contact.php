<!DOCTYPE html>
<title style>ABC Dental Hospital</title>
<link rel="stylesheet" href="site.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body style="background-color:#0AECFD;">
 <label class="logo" ><strong><h1 style="color: rgba(59, 177, 207, 0.915);">ABC DENTAL HOSPITAL </h1></strong></label>
 
 <div class="main">
  <nav>
    <div class="nav-links">
      <ul>
    <li><a href="index.php" class="home1">Home</a></li>
    <li><a href="about.php" class="photos1">About us </a></li>
    <li><a href="doctor.php" class="aboutwebsite1">Our service</a></li>
     <li><a href="contact.php" class="contacts1">Contact</a></li>
      </ul>
   </nav>
 </div>
 <div class="container">
  <h1>Contact ABC Dental Hospital</h1>

  <div class="contact-info">
      <h2>Our Address</h2>
      <p>123 Smile Street, Happy Town, NSW, Australia</p>

      <h2>Email Us</h2>
      <p>info@abcdentalhospital.com</p>

      <h2>Call Us</h2>
      <p>Phone: +61 123 456 789</p>

      <h2>Business Hours</h2>
      <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
      <p>Saturday: 10:00 AM - 4:00 PM</p>
      <p>Sunday: Closed</p>
  </div>

  <div class="contact-form">
      <h2>Send Us a Message</h2>
      <form action="#" method="post">
          <label for="name">Full Name:</label>
          <input type="text" id="name" name="name" required>

          <label for="email">Email:</label>
          <input type="email" id="email" name="email" required>

          <label for="subject">Subject:</label>
          <input type="text" id="subject" name="subject" required>

          <label for="message">Message:</label>
          <textarea id="message" name="message" rows="5" required></textarea>

          <button type="submit">Submit</button>
      </form>
  </div>
</div>
<footer>

  <div class="social-links">
    <ul>
    <li><a href="https://www.facebook.com/profile.php?id=100054698164244&mibextid=LQQJ4d" class="social-items"><i class="fa-brands fa-facebook fa-beat"></i></a></li>
    <li><a href="https://instagram.com/oscarneupane?igshid=MmIzYWVlNDQ5Yg==" class="social-items"><i class="fa-brands fa-instagram fa-beat"></i></a></li>
    <li><a href="https://www.youtube.com/@oscarvlogs4086" class="social-items"><i class="fa-brands fa-youtube fa-beat"></i></a></li>
    <li><a href="https://www.linkedin.com/in/oscar-neupane-659a41266" class="social-items"><i class="fa-brands fa-linkedin fa-beat"></i></a></li>
  </ul>
     
   </div>
  
  <div class="copyright">
  <p>copyright &copy;2024 ABCDENTALHOSPITAL. designed by oscarneupane</p>
  </div>
  </footer>
  </html>
